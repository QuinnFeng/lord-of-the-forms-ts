# My Notes on What to Make Better
